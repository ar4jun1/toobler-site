<?php
/*
    Plugin Name: Portfolio
*/

 // add_action( 'init', 'create_movie_review' );

   add_action( 'init', 'Portfolio_iteam' );

?>
